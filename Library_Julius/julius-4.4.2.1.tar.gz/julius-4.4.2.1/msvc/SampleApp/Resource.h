//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SampleApp.rc
//

#define IDS_APP_TITLE			103

#define IDR_MAINFRAME			128
#define IDD_SAMPLEAPP_DIALOG	102
#define IDD_ABOUTBOX			103
#define IDM_ABOUT				104
#define IDM_EXIT				105
#define IDI_SAMPLEAPP			107
#define IDI_SMALL				108
#define IDC_SAMPLEAPP			109
#define IDC_MYICON				2
#ifndef IDC_STATIC
#define IDC_STATIC				-1
#endif

#define IDM_OPENJCONF			32771
#define IDM_STARTPROCESS		32772
#define IDM_STOPPROCESS			32773
#define IDM_PAUSE                       32774
#define IDM_RESUME                      32775

// �V�����I�u�W�F�N�g�̎��̊���l
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32776
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
